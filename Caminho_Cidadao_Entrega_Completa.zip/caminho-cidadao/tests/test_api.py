"""Integração com MySQL de teste e falhas simuladas das dependências."""

import os
import unittest
from unittest.mock import patch

from mysql.connector import Error as ErroMySQL
from requests import Timeout

from caminho.config import chave_editor
from caminho.web import criar_app

URL = "/api/ocorrencias"
VALIDO = {"zona": "centro", "situacao": "alagado"}


class ApiTest(unittest.TestCase):
    def setUp(self):
        self.cliente = criar_app().test_client()
        self.headers = {"X-Editor-Key": chave_editor()}

    def test_painel(self):
        resposta = self.cliente.get("/")
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("Ocorrências fictícias.", resposta.get_data(as_text=True))
        self.assertIn("frame-ancestors 'none'", resposta.headers["Content-Security-Policy"])

    @unittest.skipUnless(
        os.getenv("MYSQL_DATABASE", "").endswith("_teste"),
        "Configure um banco separado com sufixo _teste para executar o CRUD.",
    )
    def test_crud_real(self):
        criada = self.cliente.post(URL, json=VALIDO, headers=self.headers)
        self.assertEqual(criada.status_code, 201)
        id_ = criada.json["id"]
        caminho = f"{URL}/{id_}"
        self.addCleanup(self.cliente.delete, caminho, headers=self.headers)

        listagem = self.cliente.get(URL)
        self.assertEqual(listagem.status_code, 200)
        dados = next(item for item in listagem.json["ocorrencias"] if item["id"] == id_)
        self.assertEqual(dados["situacao"], "alagado")
        self.assertTrue(dados["criado_em"].endswith("Z"))

        # Atualizar com os mesmos valores também deve encontrar o registro.
        self.assertEqual(self.cliente.put(caminho, json=VALIDO, headers=self.headers).status_code, 200)
        editado = {"zona": "centro", "situacao": "normalizado"}
        self.assertEqual(self.cliente.put(caminho, json=editado, headers=self.headers).status_code, 200)

        with patch("caminho.web.previsao.consultar", side_effect=Timeout):
            filtrado = self.cliente.get(f"{URL}?zona=centro")
        self.assertEqual(filtrado.status_code, 200)
        self.assertEqual(filtrado.json["previsao"], {"status": "indisponivel"})
        dados = next(item for item in filtrado.json["ocorrencias"] if item["id"] == id_)
        self.assertEqual(dados["situacao"], "normalizado")

        excluida = self.cliente.delete(caminho, headers=self.headers)
        self.assertEqual((excluida.status_code, excluida.data), (204, b""))
        self.assertEqual(self.cliente.delete(caminho, headers=self.headers).status_code, 404)
        self.assertEqual(self.cliente.put(caminho, json=VALIDO, headers=self.headers).status_code, 404)
        self.assertNotIn(id_, [item["id"] for item in self.cliente.get(URL).json["ocorrencias"]])

    def test_escrita_sem_chave(self):
        self.assertEqual(self.cliente.post(URL, json=VALIDO).status_code, 403)
        self.assertEqual(self.cliente.put(f"{URL}/1", json=VALIDO).status_code, 403)
        self.assertEqual(self.cliente.delete(f"{URL}/1").status_code, 403)

    def test_corpo_invalido(self):
        entradas = [
            {"zona": "centro' OR 1=1 --", "situacao": "alagado"},
            {"zona": "<script>alert(1)</script>", "situacao": "alagado"},
            {"zona": "centro", "situacao": []},
            {**VALIDO, "nome": "Pessoa Fictícia"},
            [],
        ]
        for entrada in entradas:
            with self.subTest(entrada=entrada):
                resposta = self.cliente.post(URL, json=entrada, headers=self.headers)
                self.assertEqual(resposta.status_code, 400)

    def test_json_e_tamanho(self):
        for corpo, tipo, esperado in [
            ("{", "application/json", 400),
            ("texto", "text/plain", 415),
            (" " * 1025, "application/json", 413),
        ]:
            with self.subTest(esperado=esperado):
                resposta = self.cliente.post(URL, data=corpo, content_type=tipo, headers=self.headers)
                self.assertEqual(resposta.status_code, esperado)

    def test_consulta_e_id_invalidos(self):
        for consulta in ("zona=centro&zona=leste", "zona=invalida", "campo=1"):
            self.assertEqual(self.cliente.get(f"{URL}?{consulta}").status_code, 400)
        self.assertEqual(self.cliente.delete(f"{URL}/0", headers=self.headers).status_code, 400)
        self.assertEqual(self.cliente.delete(f"{URL}/4294967296", headers=self.headers).status_code, 400)

    def test_falha_banco_omita_detalhes(self):
        with patch("caminho.web.banco.listar", side_effect=ErroMySQL("SEGREDO_TESTE")):
            resposta = self.cliente.get(URL)
        self.assertEqual(resposta.status_code, 503)
        self.assertEqual(resposta.json, {"erro": "Banco temporariamente indisponível."})

    def test_metodo_invalido_preserva_allow(self):
        resposta = self.cliente.patch(URL)
        self.assertEqual(resposta.status_code, 405)
        self.assertIn("GET", resposta.headers["Allow"])
