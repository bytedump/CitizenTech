# Caminho Cidadão

Protótipo CitizenTech da Global Solution de Coding for Security. Um painel local de São Paulo reúne uma **previsão pública de chuva por região** e uma lista de **ocorrências fictícias** para praticar o registro e a consulta de alagamentos.

O CGE decretou estado de atenção para alagamentos em toda a cidade em 24/01/2025. Como o monitoramento de campo do CGE se concentra nas vias principais, este protótipo explora um fluxo complementar de registros locais. O público imaginado é quem se desloca a pé ou de ônibus. A proposta se relaciona às metas 11.5 e 13.1 dos ODS. O tema é uma proposta própria para aprovação da professora.

A previsão usa um ponto aproximado por região. O painel tem fins acadêmicos e não determina a condição de uma rua. As ocorrências exibidas na demonstração são fictícias. Para ocorrências reais, consulte o [CGE](https://cge.prefeitura.sp.gov.br/v3/alagamentos.jsp).

## Executar do zero

Requisitos: Python 3.11 ou 3.12, Docker com Compose v2 e acesso à internet para instalar as dependências, baixar a imagem e consultar a previsão. Rode os comandos na pasta que contém este README.

1. Crie o ambiente virtual e copie a configuração de exemplo.

   **Windows PowerShell**

   ```powershell
   py -3.12 -m venv .venv
   Copy-Item .env.example .env
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   ```

   **Linux ou macOS**

   ```sh
   python3 -m venv .venv
   cp .env.example .env
   .venv/bin/python -m pip install -r requirements.txt
   ```

2. Gere três valores aleatórios. Use o interpretador da etapa anterior no lugar de `python` se necessário.

   ```text
   python -c "import secrets; print('MYSQL_PASSWORD=' + secrets.token_hex(18)); print('MYSQL_ROOT_PASSWORD=' + secrets.token_hex(18)); print('EDITOR_KEY=' + secrets.token_hex(24))"
   ```

   Preencha as três linhas correspondentes em `.env`. A chave de edição deve ter 24 a 128 caracteres alfanuméricos. O arquivo `.env` é ignorado pelo Git.

3. Suba o MySQL. O Compose inicializa o banco e carrega `schema.sql` no primeiro uso de um volume vazio.

   ```sh
   docker compose up -d
   docker compose logs -f mysql
   ```

   Aguarde a mensagem final `ready for connections` com `port: 3306`. Use Ctrl+C para sair da visualização dos logs. O MySQL continua rodando. O host acessa o banco pela porta 3307. Se essa porta estiver ocupada, altere `MYSQL_PORT` em `.env` antes de subir o serviço.

4. Inicie o Flask e abra [http://127.0.0.1:5000](http://127.0.0.1:5000).

   ```powershell
   .\.venv\Scripts\python.exe -m caminho.web
   ```

   ```sh
   .venv/bin/python -m caminho.web
   ```

5. Informe `EDITOR_KEY` no formulário. Registre um exemplo **Centro / Alagado**. Use o botão de edição para marcar **Normalizado**. Selecione **Centro** no filtro para solicitar a previsão. Exclua o exemplo ao terminar.

Para encerrar, use Ctrl+C no Flask e `docker compose down`. Os registros ficam no volume `dados`. Se usar uma instalação MySQL 8.4 já existente, crie o banco indicado por `MYSQL_DATABASE`, execute `schema.sql` nele com uma conta administrativa e conceda à conta da aplicação `SELECT, INSERT, UPDATE, DELETE` em `ocorrencias`. Ajuste `MYSQL_HOST` e `MYSQL_PORT` para a instalação local.

## API REST

| Verbo | Rota | Entrada | Resultado esperado |
| --- | --- | --- | --- |
| GET | `/api/ocorrencias` | Filtro opcional `?zona=centro` | 200, lista de até 100 registros recentes. Com filtro, inclui a previsão da região |
| POST | `/api/ocorrencias` | JSON + chave de edição | 201, ID, zona e situação |
| PUT | `/api/ocorrencias/<id>` | JSON completo + chave de edição | 200, ID, zona e situação |
| DELETE | `/api/ocorrencias/<id>` | ID + chave de edição | 204, sem corpo |

O cabeçalho de escrita é `X-Editor-Key`. POST e PUT usam `Content-Type: application/json` e exatamente dois campos, por exemplo `{"zona":"centro","situacao":"alagado"}`. Zonas aceitas: `centro`, `leste`, `norte`, `oeste`, `sul`. Situações aceitas: `alagado`, `normalizado`.

Erros esperados: 400 (entrada inválida), 403 (chave inválida ou ausente), 404 (recurso inexistente), 405 (método indevido), 413 (corpo acima de 1 KB), 415 (formato de mídia indevido), 503 (falha MySQL) e 500 (falha inesperada). Quando apenas a fonte meteorológica falha, o GET retorna a lista com `previsao.status = "indisponivel"`. Sem filtro, `previsao` é `null`.

## Módulo UDP e logs

O UDP roda separadamente. Em outro terminal, na mesma pasta, use o Python do ambiente virtual.

```sh
python -m caminho.udp servidor
```

Em um terceiro terminal:

```sh
python -m caminho.udp ping
python -m caminho.udp resumo
```

`PING` verifica a comunicação. `RESUMO` agrega no MySQL todos os registros por situação. O UDP ouve em `127.0.0.1:5055`, aceita dois comandos fixos e tem timeout no cliente. Os arquivos `logs/http.log` e `logs/udp.log` registram data e hora UTC, ação e resultado. Exemplo de formato: `2026-11-09T21:00:00Z acao=criar resultado=HTTP_201`. Chaves, IPs, corpos e valores submetidos ficam fora desses arquivos. Use uma instância de cada serviço para a demonstração.

## Arquitetura e validação

- `caminho/web.py` valida e autoriza a entrada e monta a resposta HTTP.
- `caminho/banco.py` abre conexões curtas com MySQL, vincula parâmetros em statements preparados e faz commit. `schema.sql` define os campos e valores válidos.
- `caminho/previsao.py` usa requests para consultar JSON no Open-Meteo. O destino e as coordenadas estão definidos no código.
- `caminho/udp.py` implementa o servidor e cliente UDP. `caminho/auditoria.py` configura os logs.
- `caminho/templates/` e `caminho/static/` contêm HTML, CSS e JS. O navegador usa `fetch` para chamar a API.
- `tests/` cobre o CRUD e os erros usando Flask e um banco MySQL de teste. Para rodar os testes, crie um **banco descartável e separado com sufixo `_teste`** com a tabela de `schema.sql` e configure as credenciais correspondentes no ambiente do processo. Os testes criam e removem seus próprios registros. Não rode com os serviços públicos.

**Linux ou macOS**

```sh
MYSQL_DATABASE=caminho_teste .venv/bin/python -m unittest discover -s tests -v
```

**Windows PowerShell**

```powershell
$env:MYSQL_DATABASE = "caminho_teste"
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
Remove-Item Env:MYSQL_DATABASE
```

Esses exemplos pressupõem que a conta do `.env` tem acesso a `caminho_teste`. Sem o sufixo, o teste que grava no banco é pulado. Os demais usam entradas inválidas ou simulações.

Para a arguição, siga uma ocorrência do formulário até o `INSERT` parametrizado. Mostre o código 403 com uma chave errada e o 400 com uma zona inválida. Compare uma consulta de previsão com a contagem via UDP. Explique por que o painel usa regiões predefinidas, quais dados o MySQL guarda e o que acontece quando uma das integrações cai.

A chave de edição é compartilhada para a demonstração local. Ela dá os mesmos poderes a todo portador. O protótipo usa HTTP local e UDP local e não foi avaliado em campo. A adoção pública exigiria autenticação individual, TLS, moderação e um processo de verificação e expiração de registros.

## Publicar no GitHub

Com Git e [GitHub CLI](https://cli.github.com/) instalados, crie um repositório privado a partir desta pasta. Confira em `git status` que o arquivo `.env` não entrou no commit.

```sh
git init -b main
git add .
git status --short
git commit -m "Adiciona protótipo Caminho Cidadão"
gh auth login
gh repo create caminho-cidadao --private --source=. --remote=origin --push
```

Para a entrega, use o link do repositório. Se mantiver a visibilidade privada, conceda acesso à professora.

## Referências e declaração de uso de IA

- [Prefeitura de São Paulo · estado de atenção em 24/01/2025](https://prefeitura.sp.gov.br/w/cge-decreta-estado-de-aten%C3%A7%C3%A3o-para-alagamentos-em-toda-a-cidade-%C3%A0s-15h27)
- [CGE · cobertura e classificação de alagamentos](https://cge.prefeitura.sp.gov.br/v3/alagamentos-classificacao.jsp)
- [ONU Brasil · ODS 11](https://brasil.un.org/pt-br/sdgs/11) e [ODS 13](https://brasil.un.org/pt-br/sdgs/13)
- [Open-Meteo · documentação e atribuição da previsão](https://open-meteo.com/en/docs)
- [Planalto · LGPD, art. 6º](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm)
- Referências de implementação: [Flask](https://flask.palletsprojects.com/), [MySQL Connector/Python](https://dev.mysql.com/doc/connector-python/en/), [requests](https://requests.readthedocs.io/), [python-dotenv](https://bbc2.github.io/python-dotenv/) e [socket do Python](https://docs.python.org/3/library/socket.html). As bibliotecas são dependências externas identificadas em `requirements.txt`. O código da aplicação foi escrito para este protótipo.

O ChatGPT ajudou a estruturar a proposta, gerar a versão inicial do código, depurar, testar e redigir a documentação. Esta versão serve de base para revisão, execução e explicação individual antes da entrega acadêmica.
