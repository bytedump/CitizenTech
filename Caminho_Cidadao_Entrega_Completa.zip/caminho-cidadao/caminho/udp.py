"""Canal local de leitura para acompanhar a contagem sem navegador."""

import argparse
import json
import socket

from mysql.connector import Error as ErroMySQL

from . import banco
from .auditoria import configurar_log

ENDERECO = ("127.0.0.1", 5055)
COMANDOS = {"ping": b"PING", "resumo": b"RESUMO"}


def servir():
    log = configurar_log("udp")
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as servidor:
        servidor.bind(ENDERECO)
        print("UDP local em 127.0.0.1:5055. Ctrl+C encerra.")
        while True:
            try:
                mensagem, origem = servidor.recvfrom(128)
            except OSError:
                log.info("acao=receber resultado=falha")
                raise
            if mensagem == COMANDOS["ping"]:
                acao, resposta = "ping", {"status": "ok"}
            elif mensagem == COMANDOS["resumo"]:
                acao = "resumo"
                try:
                    resposta = {"status": "ok", "contagens": banco.resumo()}
                except (ErroMySQL, RuntimeError, ValueError):
                    resposta = {"status": "banco_indisponivel"}
            else:
                acao, resposta = "comando_invalido", {"status": "comando_invalido"}
            try:
                servidor.sendto(json.dumps(resposta).encode("utf-8"), origem)
            except OSError:
                log.info("acao=%s resultado=falha_envio", acao)
            else:
                log.info("acao=%s resultado=%s", acao, resposta["status"])


def consultar(comando):
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as cliente:
        cliente.settimeout(6)
        cliente.connect(ENDERECO)
        cliente.send(COMANDOS[comando])
        print(cliente.recv(256).decode("utf-8"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Servidor e cliente UDP locais.")
    parser.add_argument("modo", choices=["servidor", *COMANDOS])
    modo = parser.parse_args().modo
    try:
        if modo == "servidor":
            servir()
        else:
            consultar(modo)
    except KeyboardInterrupt:
        print("\nServidor encerrado.")
    except OSError:
        parser.exit(1, "Falha de comunicação UDP. Confira o serviço e a porta 5055.\n")
