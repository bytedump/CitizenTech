"""Registra ações conhecidas e seus resultados, em UTC."""

import logging
from logging.handlers import RotatingFileHandler
from time import gmtime

from .config import ROOT


def configurar_log(canal):
    logger = logging.getLogger(f"caminho.{canal}")
    if not logger.handlers:
        pasta = ROOT / "logs"
        pasta.mkdir(exist_ok=True)
        arquivo = RotatingFileHandler(
            pasta / f"{canal}.log", maxBytes=256_000, backupCount=2, encoding="utf-8"
        )
        formato = logging.Formatter("%(asctime)sZ %(message)s", "%Y-%m-%dT%H:%M:%S")
        formato.converter = gmtime
        arquivo.setFormatter(formato)
        logger.addHandler(arquivo)
        logger.setLevel(logging.INFO)
        logger.propagate = False
        # Em caso de falha de escrita, não imprime detalhes internos na saída.
        logging.raiseExceptions = False
    return logger
