"""Consulta previsão de precipitação para uma região predefinida."""

from datetime import datetime
from math import isfinite

import requests

from .config import ZONAS

URL = "https://api.open-meteo.com/v1/forecast"
FUSO = "America/Sao_Paulo"


def consultar(zona):
    _, latitude, longitude = ZONAS[zona]
    resposta = requests.get(
        URL,
        params={
            "latitude": latitude,
            "longitude": longitude,
            "hourly": "precipitation",
            "forecast_hours": 6,
            "timezone": FUSO,
        },
        timeout=(4, 7),
        allow_redirects=False,
    )
    resposta.raise_for_status()
    if resposta.status_code != 200:
        raise ValueError("Status inesperado da fonte.")
    dados = resposta.json()
    horarios = dados["hourly"]["time"]
    valores = dados["hourly"]["precipitation"]
    if dados["hourly_units"]["precipitation"] != "mm":
        raise ValueError("Unidade inesperada.")
    if not isinstance(horarios, list) or not isinstance(valores, list):
        raise ValueError("Série inválida.")
    if len(horarios) != 6 or len(valores) != 6:
        raise ValueError("Série incompleta.")

    horas = []
    for horario, mm in zip(horarios, valores):
        datetime.strptime(horario, "%Y-%m-%dT%H:%M")
        if type(mm) not in (int, float) or not 0 <= mm or not isfinite(mm):
            raise ValueError("Precipitação inválida.")
        horas.append({"horario_local": horario, "mm": mm})
    return {"status": "disponivel", "fuso": FUSO, "horas": horas}
