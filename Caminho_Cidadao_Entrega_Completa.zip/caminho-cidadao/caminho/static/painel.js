"use strict";

const API = "/api/ocorrencias";
const porId = (id) => document.getElementById(id);
const formulario = porId("formulario");
const filtro = porId("filtro");
const zona = porId("zona");
const situacao = porId("situacao");
const chave = porId("chave");
const lista = porId("lista");
const listaStatus = porId("lista-status");
const formStatus = porId("form-status");
const chuvaStatus = porId("chuva-status");
const chuvaHoras = porId("chuva-horas");
const dataHora = new Intl.DateTimeFormat("pt-BR", {
  dateStyle: "short", timeStyle: "short", timeZone: "America/Sao_Paulo",
});
const numero = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 });
let idEditado = null;
let consultaAtual = 0;
let gravando = false;

async function requisitar(url, opcoes) {
  const resposta = await fetch(url, opcoes);
  if (resposta.status === 204) return null;
  const dados = await resposta.json();
  if (!resposta.ok) throw new Error(dados.erro || "Falha na requisição.");
  return dados;
}

function mensagemDeErro(erro) {
  return erro instanceof TypeError || erro instanceof SyntaxError
    ? "Falha de comunicação com o painel."
    : erro.message;
}

function texto(tag, conteudo, classe) {
  const elemento = document.createElement(tag);
  elemento.textContent = conteudo;
  if (classe) elemento.className = classe;
  return elemento;
}

function nomeOpcao(select, valor) {
  return [...select.options].find((opcao) => opcao.value === valor)?.textContent || valor;
}

function botao(rotulo, acao) {
  const elemento = texto("button", rotulo, "secundario");
  elemento.type = "button";
  elemento.addEventListener("click", acao);
  return elemento;
}

function mostrarOcorrencias(ocorrencias) {
  lista.replaceChildren();
  listaStatus.textContent = ocorrencias.length
    ? `${ocorrencias.length} registro(s) recente(s).`
    : "Nenhuma ocorrência simulada nesta seleção.";
  for (const item of ocorrencias) {
    const linha = texto("li", "", "item");
    const titulo = document.createElement("p");
    titulo.append(
      texto("strong", `#${item.id} · ${nomeOpcao(zona, item.zona)}`),
      texto("span", nomeOpcao(situacao, item.situacao), `selo ${item.situacao}`),
    );
    const acoes = texto("div", "", "acoes");
    acoes.append(
      botao(`Editar #${item.id}`, () => editar(item)),
      botao(`Excluir #${item.id}`, () => excluir(item)),
    );
    linha.append(titulo, texto("small", `Atualizado em ${dataHora.format(new Date(item.atualizado_em))}`), acoes);
    lista.append(linha);
  }
}

function mostrarChuva(previsao) {
  chuvaHoras.replaceChildren();
  if (!previsao) {
    chuvaStatus.textContent = "Escolha uma região para consultar seis horários.";
    return;
  }
  if (previsao.status !== "disponivel") {
    chuvaStatus.textContent = "Previsão indisponível agora. As ocorrências continuam disponíveis.";
    return;
  }
  chuvaStatus.textContent = "Acumulado previsto por hora, em milímetros.";
  for (const hora of previsao.horas) {
    const linha = document.createElement("li");
    const quando = texto("time", hora.horario_local.slice(8, 10) + " · " + hora.horario_local.slice(11));
    quando.dateTime = hora.horario_local;
    linha.append(quando, texto("strong", `${numero.format(hora.mm)} mm`));
    chuvaHoras.append(linha);
  }
}

async function carregar() {
  const consulta = ++consultaAtual;
  const selecionada = filtro.value;
  listaStatus.textContent = "Carregando ocorrências…";
  lista.replaceChildren();
  chuvaHoras.replaceChildren();
  chuvaStatus.textContent = selecionada ? "Consultando previsão…" : "Escolha uma região para consultar seis horários.";
  try {
    const url = selecionada ? `${API}?zona=${encodeURIComponent(selecionada)}` : API;
    const dados = await requisitar(url);
    if (consulta !== consultaAtual) return;
    mostrarOcorrencias(dados.ocorrencias);
    mostrarChuva(dados.previsao);
  } catch (erro) {
    if (consulta !== consultaAtual) return;
    listaStatus.textContent = mensagemDeErro(erro);
    chuvaStatus.textContent = "Previsão indisponível.";
  }
}

function editar(item) {
  if (gravando) return;
  idEditado = item.id;
  zona.value = item.zona;
  situacao.value = item.situacao;
  porId("titulo-editor").textContent = `Editar ocorrência #${item.id}`;
  porId("salvar").textContent = "Salvar alteração";
  porId("cancelar").hidden = false;
  formStatus.textContent = "";
  zona.focus();
}

function limparEditor() {
  idEditado = null;
  zona.selectedIndex = 0;
  situacao.selectedIndex = 0;
  porId("titulo-editor").textContent = "Nova ocorrência";
  porId("salvar").textContent = "Registrar ocorrência";
  porId("cancelar").hidden = true;
}

async function mutacao(metodo, id, dados) {
  if (gravando) return false;
  if (!chave.reportValidity()) return false;
  const headers = { "X-Editor-Key": chave.value };
  const opcoes = { method: metodo, headers };
  if (dados) {
    headers["Content-Type"] = "application/json";
    opcoes.body = JSON.stringify(dados);
  }
  gravando = true;
  porId("salvar").disabled = true;
  porId("cancelar").disabled = true;
  try {
    await requisitar(id === null ? API : `${API}/${id}`, opcoes);
    return true;
  } catch (erro) {
    formStatus.textContent = mensagemDeErro(erro);
    return false;
  } finally {
    gravando = false;
    porId("salvar").disabled = false;
    porId("cancelar").disabled = false;
  }
}

async function excluir(item) {
  if (gravando || !chave.reportValidity()) return;
  if (!window.confirm(`Excluir a ocorrência simulada #${item.id}?`)) return;
  if (await mutacao("DELETE", item.id)) {
    if (idEditado === item.id) limparEditor();
    formStatus.textContent = `Ocorrência #${item.id} excluída.`;
    await carregar();
  }
}

formulario.addEventListener("submit", async (evento) => {
  evento.preventDefault();
  const editando = idEditado !== null;
  const sucesso = await mutacao(editando ? "PUT" : "POST", idEditado, {
    zona: zona.value, situacao: situacao.value,
  });
  if (sucesso) {
    limparEditor();
    formStatus.textContent = editando ? "Ocorrência atualizada." : "Ocorrência registrada.";
    await carregar();
  }
});
porId("cancelar").addEventListener("click", () => {
  limparEditor();
  formStatus.textContent = "";
});
filtro.addEventListener("change", carregar);
carregar();
