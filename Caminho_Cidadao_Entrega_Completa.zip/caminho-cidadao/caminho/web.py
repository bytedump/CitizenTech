"""Interface HTML e quatro operações REST da demonstração."""

from functools import wraps
from hmac import compare_digest
import logging

from flask import Flask, abort, jsonify, render_template, request
from mysql.connector import Error as ErroMySQL
from requests import RequestException
from werkzeug.exceptions import HTTPException

from . import banco, previsao
from .auditoria import configurar_log
from .config import SITUACOES, ZONAS, chave_editor


def criar_app():
    app = Flask(__name__)
    app.config.update(MAX_CONTENT_LENGTH=1024, TRUSTED_HOSTS=["127.0.0.1", "localhost"])
    editor = chave_editor()
    log = configurar_log("http")
    logging.getLogger("werkzeug").setLevel(logging.ERROR)

    def escrita(funcao):
        @wraps(funcao)
        def proteger(*args, **kwargs):
            chave = request.headers.get("X-Editor-Key", "")
            if not chave.isascii() or not compare_digest(chave, editor):
                abort(403)
            return funcao(*args, **kwargs)
        return proteger

    def corpo_validado():
        dados = request.get_json()
        if not isinstance(dados, dict) or set(dados) != {"zona", "situacao"}:
            abort(400)
        zona, situacao = dados["zona"], dados["situacao"]
        if not isinstance(zona, str) or zona not in ZONAS:
            abort(400)
        if not isinstance(situacao, str) or situacao not in SITUACOES:
            abort(400)
        return zona, situacao

    @app.before_request
    def validar_requisicao():
        if request.endpoint not in {"listar", "criar", "atualizar", "excluir"}:
            return
        campos = request.args
        if campos and (
            request.endpoint != "listar"
            or set(campos) != {"zona"}
            or len(campos.getlist("zona")) != 1
            or campos["zona"] not in ZONAS
        ):
            abort(400)
        if request.view_args:
            id_ = request.view_args["id_"]
            if not 1 <= id_ <= 4_294_967_295:
                abort(400)
        if request.method not in {"POST", "PUT"} and request.get_data():
            abort(400)

    @app.get("/")
    def painel():
        return render_template("index.html", zonas=ZONAS, situacoes=SITUACOES)

    @app.get("/api/ocorrencias")
    def listar():
        zona = request.args.get("zona")
        ocorrencias = banco.listar(zona)
        chuva = None
        if zona:
            try:
                chuva = previsao.consultar(zona)
            except (RequestException, ValueError, TypeError, KeyError, OverflowError):
                chuva = {"status": "indisponivel"}
            log.info("acao=previsao resultado=%s", chuva["status"])
        return jsonify(ocorrencias=ocorrencias, previsao=chuva)

    @app.post("/api/ocorrencias")
    @escrita
    def criar():
        zona, situacao = corpo_validado()
        id_ = banco.criar(zona, situacao)
        return jsonify(id=id_, zona=zona, situacao=situacao), 201

    @app.put("/api/ocorrencias/<int:id_>")
    @escrita
    def atualizar(id_):
        zona, situacao = corpo_validado()
        if not banco.atualizar(id_, zona, situacao):
            abort(404)
        return jsonify(id=id_, zona=zona, situacao=situacao)

    @app.delete("/api/ocorrencias/<int:id_>")
    @escrita
    def excluir(id_):
        if not banco.excluir(id_):
            abort(404)
        return "", 204

    @app.errorhandler(ErroMySQL)
    def erro_banco(_erro):
        return jsonify(erro="Banco temporariamente indisponível."), 503

    @app.errorhandler(HTTPException)
    def erro_http(erro):
        mensagens = {
            400: "Entrada inválida. Confira a região, a situação ou o ID.",
            403: "Chave de edição inválida ou ausente.",
            404: "Recurso não encontrado.",
            405: "Método não permitido.",
            413: "Corpo da requisição excede 1 KB.",
            415: "Envie um objeto com Content-Type application/json.",
        }
        resposta = erro.get_response()
        resposta.set_data(app.json.dumps({"erro": mensagens.get(erro.code, "Falha na requisição.")}))
        resposta.mimetype = "application/json"
        return resposta

    @app.errorhandler(Exception)
    def erro_interno(_erro):
        return jsonify(erro="Falha interna."), 500

    @app.after_request
    def proteger_resposta(resposta):
        resposta.headers["Content-Security-Policy"] = (
            "default-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'"
        )
        resposta.headers["X-Content-Type-Options"] = "nosniff"
        resposta.headers["Referrer-Policy"] = "no-referrer"
        if request.path.startswith("/api/"):
            acao = request.endpoint or "rota_invalida"
            log.info("acao=%s resultado=HTTP_%s", acao, resposta.status_code)
            resposta.headers["Cache-Control"] = "no-store"
        return resposta

    return app


if __name__ == "__main__":
    criar_app().run(host="127.0.0.1", port=5000, debug=False)
