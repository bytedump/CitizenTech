"""Configurações locais e vocabulário fixo do protótipo."""

import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")

# Pontos aproximados em São Paulo. Nenhuma coordenada vem do usuário.
ZONAS = {
    "centro": ("Centro", -23.55, -46.63),
    "leste": ("Zona Leste", -23.54, -46.48),
    "norte": ("Zona Norte", -23.48, -46.62),
    "oeste": ("Zona Oeste", -23.56, -46.73),
    "sul": ("Zona Sul", -23.67, -46.68),
}
SITUACOES = {"alagado": "Alagado", "normalizado": "Normalizado"}


def obrigatoria(nome):
    valor = os.getenv(nome)
    if not valor:
        raise RuntimeError(f"Preencha {nome} no arquivo .env.")
    return valor


def chave_editor():
    chave = obrigatoria("EDITOR_KEY")
    if not 24 <= len(chave) <= 128 or not chave.isascii() or not chave.isalnum():
        raise RuntimeError("Use uma EDITOR_KEY alfanumérica de 24 a 128 caracteres.")
    return chave
