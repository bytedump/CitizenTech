"""CRUD em MySQL com SQL explícito e parâmetros vinculados pelo driver."""

from contextlib import contextmanager

import mysql.connector
from mysql.connector.constants import ClientFlag

from .config import obrigatoria


@contextmanager
def cursor_mysql():
    with mysql.connector.connect(
        host=obrigatoria("MYSQL_HOST"),
        port=int(obrigatoria("MYSQL_PORT")),
        database=obrigatoria("MYSQL_DATABASE"),
        user=obrigatoria("MYSQL_USER"),
        password=obrigatoria("MYSQL_PASSWORD"),
        connection_timeout=3,
        read_timeout=3,
        write_timeout=3,
        time_zone="+00:00",
        client_flags=[ClientFlag.FOUND_ROWS],
        use_pure=True,
    ) as conexao:
        with conexao.cursor(prepared=True) as cursor:
            yield cursor
        conexao.commit()


def listar(zona=None):
    with cursor_mysql() as cursor:
        cursor.execute(
            """
            SELECT id, zona, situacao, criado_em, atualizado_em
            FROM ocorrencias
            WHERE (%s IS NULL OR zona = %s)
            ORDER BY id DESC LIMIT 100
            """,
            (zona, zona),
        )
        return [
            {
                "id": id_,
                "zona": zona_linha,
                "situacao": situacao,
                "criado_em": criado.isoformat(timespec="seconds") + "Z",
                "atualizado_em": atualizado.isoformat(timespec="seconds") + "Z",
            }
            for id_, zona_linha, situacao, criado, atualizado in cursor.fetchall()
        ]


def criar(zona, situacao):
    with cursor_mysql() as cursor:
        cursor.execute(
            "INSERT INTO ocorrencias (zona, situacao) VALUES (%s, %s)",
            (zona, situacao),
        )
        return cursor.lastrowid


def atualizar(id_, zona, situacao):
    with cursor_mysql() as cursor:
        cursor.execute(
            "UPDATE ocorrencias SET zona = %s, situacao = %s WHERE id = %s",
            (zona, situacao, id_),
        )
        return cursor.rowcount == 1


def excluir(id_):
    with cursor_mysql() as cursor:
        cursor.execute("DELETE FROM ocorrencias WHERE id = %s", (id_,))
        return cursor.rowcount == 1


def resumo():
    with cursor_mysql() as cursor:
        cursor.execute("SELECT situacao, COUNT(*) FROM ocorrencias GROUP BY situacao")
        contagens = {"alagado": 0, "normalizado": 0}
        contagens.update(cursor.fetchall())
        return contagens
